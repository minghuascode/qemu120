
This package contains pre-built binaries of the kickstart and
stage 1 loaders (s1L) for the Embedded Artists 3250 board. It also
contains software to burn the images into FLASH via UART 5 on the
LPC32x0 usnig the Serial Loader tool.

Supported boot images:
Kickstart boot for large block NAND FLASH
	This version of the kickstart loader loads the stage 1 application from
	block 1 of NAND FLASH into address 0x8000 with size 128K.

Support S1L images
S1L boot from large block FLASH
	This version of S1L requires a kickstart loader to load and it and
	start it. This version doesn't initializes SDRAM or board functions and
	should be used with the large block NAND FLASH kickstart loader.

S1L boot from IRAM
	This version of S1L loads directly into IRAM with the Serial Loader
	tool. It initializes SDRAM and board functions.

Eraser images:
The eraser image erases the first block of NAND FLASH. It is intended to disable
the NAND boot method if needed by erasing the boot id used by the LPC32x0 boot
ROM.

Kickstart and S1L update procedure:
To uodate an image using the Serial loader, make sure the nService mode on the
Embedded Artists board is enabled (See EA documentation) and connect a USB
cable between a PC and the serial/USB interface on the board. Start the Serial
Loader tool (LPC3250_Loader.exe) on the PC and set the serial port on the tool
GUI to the correct serial port on the PC.

To update the factory large small block kickstart and S1L images:
This procedure updates the factory installed kickstart and S1L images to the
latest v2.0 code included in this package. In the serial loader tool
"Primary boot (IRAM)" box, select the "burner_kickstart_nand_large_block_rvw.bin"
file and make sure the check is active next to the box. In the serial loader tool
"Secondary boot (SDRAM)" box, select the "kickstart_nand_large_block_rvw.bin"
file and make sure the check is active next to the box. Press the "Load bin's start
primat" button and then power up the board or press reset if the board is already
pwoered up. The software will transfer and download. Once transfer is complete,
press the "Enable terminal mode" button and monitor the output messages in the
tool for completion. The same process should be used with the
"burner_s1app_nand_large_block_rvw.bin" (primary) and the
"s1l_from_kick_rvw.bin" (secondary) files to update S1L. Once the updates are
omplete, reset the board to boot the updated software.

S1L running directly from IRAM:
The other images can also be deployed with the Serial loader tool. S1L can be
downloaded directly into IRAM from the serial loader tool by selecting the
"s1l_from_iram_rvw.bin" binary in the "Primary boot (IRAM)" window , pressing the
"Load bin's start primat" button and then powering up or reseting the board. The
file will transfer and automatically start.

******************************************************************************
* Summary image combinations
******************************************************************************
To boot kickstart and S1L from NAND FLASH, use with the serial loader:
For kickstart:
Primary boot (IRAM)         -> burner_kickstart_nand_large_block_rvw.bin
Secondary executable (IRAM) -> kickstart_nand_large_block_rvw.bin

For s1L:
Primary boot (IRAM)         -> burner_s1app_nand_large_block_rvw.bin
Secondary executable (IRAM) -> s1l_from_kick_rvw.bin

To boot S1L from UART5, use with the serial loader:
For s1L:
Primary boot (IRAM)         -> s1l_from_iram_rvw.bin
Secondary executable (IRAM) -> *do not use, make sure this is unchecked*
