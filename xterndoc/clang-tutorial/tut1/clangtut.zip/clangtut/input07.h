
static int static_h = 4, static_h_2 = 9;

EXTERN int bla INIT(4);
