


#define A_h(x) int x;
#define B_h(x) A(x ## 1) A(x ## 2)

int c;

#define tA_h(x) x myvar;
