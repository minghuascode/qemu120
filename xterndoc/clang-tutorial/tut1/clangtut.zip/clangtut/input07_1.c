#define EXTERN
#define INIT(a) =a

#include "input07.h"

int blah = 8;

int f()
{
  int s = static_h;
  int t = static_h_2;
  int u = bla;
  int v = blah;
}
